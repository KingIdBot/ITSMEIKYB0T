## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px">ITSMEIKY BOT
<p align="center">
<img src="https://camo.githubusercontent.com/0afcc6050ce6d1858e1f8136ad418fadea998a0188ae20364504ed6c9bbb6b2c/68747470733a2f2f696d61676573352e616c706861636f646572732e636f6d2f3931312f3931313631342e706e67" width="400" height="230"/>
</p>
<p align="center">
<p align="center">
<a href="#"><img title="ITSMEIKY BOT" src="https://img.shields.io/badge/ITSMEIKY-BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">


♡WhatsApp BOT On Termux♡

```Termux Command 
> git clone https://github.com/itsmeikybot/ITSMEIKYB0T
```
```Next Command
> cd ITSMEIKYB0T
> bash install.sh
```
```
> node index.js 
```
